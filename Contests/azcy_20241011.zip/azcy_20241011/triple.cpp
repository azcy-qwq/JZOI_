#include<bits/stdc++.h>
using namespace std;
int main(){
//ios::sync_with_stdio(0);
    int n;
    cin>>n;
    if(n<3) cout<<"-1 -1 -1";
    else cout<<"1 2 3";
    // dbg(Gcd(a*b,a*c,b*c)*Gcd(a,b,c)/Gcd(a*b*b,a*c*c,b*a*a,b*c*c,c*a*a,c*b*b));
}